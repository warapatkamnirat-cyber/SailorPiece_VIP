--[[
    =========================================================
    🦖 Dinobees Hub VIP | เวอร์ชั่น v0.0.0.1 (Full Version)
    ผู้พัฒนา: Prime Store
    ลิขสิทธิ์: องค์กร Prime Store
    เกม: Sailor Piece
    =========================================================
]]

-- [ ตั้งค่าเบื้องต้น ]
local MyCustomIconID = "rbxassetid://123456789" -- เปลี่ยนเป็น ID ไอคอนของคุณ
local WebhookURL = "Dinobees.png" -- ใส่ลิงก์ Discord Webhook (ถ้ามี)

-- [ บริการต่างๆ ของ Roblox ]
local Players = game:GetService("Players")
local Player = Players.LocalPlayer
local RunService = game:GetService("RunService")
local TweenService = game:GetService("TweenService")
local HttpService = game:GetService("HttpService")
local VirtualUser = game:GetService("VirtualUser")
local TeleportService = game:GetService("TeleportService")

-- [ ตัวแปรสถานะการทำงาน ]
_G.AutoFarm = false
_G.BringMob = false
_G.FastAttack = false
_G.KillAura = false
_G.AutoBoss = false
_G.AutoEvent = false
_G.AutoCollect = false
_G.AutoGrabFruit = false
_G.AutoMastery = false
_G.AFKMode = false
_G.TweenSpeed = 150

-- ==========================================
-- 🛠️ ฟังก์ชันระบบหลัก (Core Functions)
-- ==========================================

-- ดึงตัวละครที่อัปเดตเสมอ (กันบัคตอนตาย)
local function GetRoot()
    local char = Player.Character or Player.CharacterAdded:Wait()
    return char:WaitForChild("HumanoidRootPart", 5)
end

-- ระบบวาร์ป (Safe Tween)
local function SafeTween(targetCFrame)
    pcall(function()
        local root = GetRoot()
        if root and targetCFrame then
            local dist = (root.Position - targetCFrame.Position).Magnitude
            local info = TweenInfo.new(dist / _G.TweenSpeed, Enum.EasingStyle.Linear)
            TweenService:Create(root, info, {CFrame = targetCFrame}):Play()
        end
    end)
end

-- ระบบดึงมอนสเตอร์ (Smart Mob Magnet)
local function BringMonsters()
    if _G.BringMob then
        for _, v in pairs(workspace.Enemies:GetChildren()) do
            if v:FindFirstChild("HumanoidRootPart") and v:FindFirstChild("Humanoid") and v.Humanoid.Health > 0 then
                local dist = (v.HumanoidRootPart.Position - GetRoot().Position).Magnitude
                if dist <= 300 then
                    v.HumanoidRootPart.CFrame = GetRoot().CFrame * CFrame.new(0, 0, -5)
                    v.HumanoidRootPart.CanCollide = false
                end
            end
        end
    end
end

-- ระบบลดความหน่วงสูงสุด (Extreme Optimize)
local function OptimizeGame()
    settings().Rendering.QualityLevel = Enum.QualityLevel.Level01
    for _, v in pairs(game:GetDescendants()) do
        if v:IsA("Part") or v:IsA("MeshPart") then
            v.Material = Enum.Material.SmoothPlastic
            v.Reflectance = 0
        elseif v:IsA("Decal") or v:IsA("Texture") then
            v:Destroy()
        elseif v:IsA("ParticleEmitter") or v:IsA("Trail") then
            v.Enabled = false
        end
    end
    game:GetService("Lighting").GlobalShadows = false
    collectgarbage("collect")
end

-- ระบบสลับเซิร์ฟเวอร์ (Server Hop)
local function ServerHop()
    local Api = "https://games.roblox.com/v1/games/" .. game.PlaceId .. "/servers/Public?sortOrder=Asc&limit=100"
    local function ListServers(cursor)
        local Raw = game:HttpGet(Api .. ((cursor and "&cursor=" .. cursor) or ""))
        return HttpService:JSONDecode(Raw)
    end
    local Server = ListServers()
    for _, v in pairs(Server.data) do
        if v.playing < v.maxPlayers and v.id ~= game.JobId then
            TeleportService:TeleportToPlaceInstance(game.PlaceId, v.id)
            break
        end
    end
end

-- ระบบประหยัดพลังงานข้ามคืน (Night Farm / AFK Mode)
local function SetAFKMode(Value)
    _G.AFKMode = Value
    if _G.AFKMode then
        local ScreenGui = Instance.new("ScreenGui", game.CoreGui)
        ScreenGui.Name = "PrimeStore_AFK"
        ScreenGui.DisplayOrder = 9999
        local Frame = Instance.new("Frame", ScreenGui)
        Frame.Size = UDim2.new(1, 0, 1, 0)
        Frame.BackgroundColor3 = Color3.new(0, 0, 0)
        local Text = Instance.new("TextLabel", Frame)
        Text.Text = "🦖 Dinobees VIP ฟาร์มทำงานอยู่...\n(คลิกหน้าจอ 3 ครั้งเพื่อปิด)"
        Text.TextColor3 = Color3.new(1, 1, 1)
        Text.Size = UDim2.new(1, 0, 1, 0)
        Text.BackgroundTransparency = 1
        Text.TextSize = 25
        
        RunService:Set3dRenderingEnabled(false) -- ปิดภาพ 3D
        if setfpscap then setfpscap(15) end -- ลด FPS
        
        local clicks = 0
        local conn
        conn = game:GetService("UserInputService").InputBegan:Connect(function(i)
            if i.UserInputType == Enum.UserInputType.MouseButton1 or i.UserInputType == Enum.UserInputType.Touch then
                clicks = clicks + 1
                if clicks >= 3 then 
                    SetAFKMode(false) 
                    conn:Disconnect() 
                end
            end
        end)
    else
        if game.CoreGui:FindFirstChild("PrimeStore_AFK") then game.CoreGui.PrimeStore_AFK:Destroy() end
        RunService:Set3dRenderingEnabled(true)
        if setfpscap then setfpscap(60) end
    end
end

-- ป้องกันเกมเตะเมื่อไม่ขยับ (Anti-AFK)
Player.Idled:Connect(function()
    VirtualUser:CaptureController()
    VirtualUser:ClickButton2(Vector2.new(0,0))
end)

-- ==========================================
-- 🎨 ระบบ UI (Rayfield & Floating Icon)
-- ==========================================
local Rayfield = loadstring(game:HttpGet('https://sirius.menu/rayfield'))()

-- สร้างไอคอนลอยของ Prime Store
local function CreateFloatingIcon()
    local gui = Instance.new("ScreenGui", game.CoreGui)
    gui.Name = "PrimeStore_Icon"
    local btn = Instance.new("ImageButton", gui)
    btn.Image = MyCustomIconID
    btn.Size = UDim2.new(0, 50, 0, 50)
    btn.Position = UDim2.new(0, 10, 0.5, -25)
    btn.BackgroundTransparency = 1
    btn.ImageTransparency = 0.3
    btn.Draggable = true
    Instance.new("UICorner", btn).CornerRadius = UDim.new(1, 0)
    
    btn.MouseEnter:Connect(function() btn.ImageTransparency = 0 end)
    btn.MouseLeave:Connect(function() btn.ImageTransparency = 0.3 end)
    btn.MouseButton1Click:Connect(function() Rayfield:ToggleButton() end)
end
CreateFloatingIcon()

local Window = Rayfield:CreateWindow({
   Name = "🦖 Dinobees VIP v0.0.0.1 | Prime Store",
   LoadingTitle = "Prime Store Advanced System",
   LoadingSubtitle = "ลิขสิทธิ์โดย องค์กร Prime Store",
   ConfigurationSaving = { Enabled = true, FolderName = "Dinobees_VIP", FileName = "Config" },
   KeySystem = false
})

-- 🏠 หน้าหลัก
local HomeTab = Window:CreateTab("🏠 หน้าหลัก", 4483362458)
HomeTab:CreateParagraph({Title = "ประกาศจากองค์กร", Content = "อัปเดต VIP v0.0.0.1: รวมระบบแก้บัคและฟาร์มข้ามคืน"})
local StatsLabel = HomeTab:AddLabel("สถิติ: กำลังโหลด...")

-- 🚜 ฟาร์มอัตโนมัติ
local FarmTab = Window:CreateTab("🚜 ฟาร์ม", 4483362458)
FarmTab:CreateToggle({Name = "เริ่มฟาร์มอัตโนมัติ (Smart Mode)", CurrentValue = false, Callback = function(V) _G.AutoFarm = V end})
FarmTab:CreateToggle({Name = "รวมมอนสเตอร์ (Mob Magnet)", CurrentValue = false, Callback = function(V) _G.BringMob = V end})
FarmTab:CreateToggle({Name = "ตีเร็วสูงสุด (Fast Attack 0 Delay)", CurrentValue = false, Callback = function(V) _G.FastAttack = V end})
FarmTab:CreateToggle({Name = "ฟาร์มความชำนาญ (Auto Mastery)", CurrentValue = false, Callback = function(V) _G.AutoMastery = V end})

-- ⚔️ ต่อสู้ & บอส
local CombatTab = Window:CreateTab("⚔️ ต่อสู้ & บอส", 4483362458)
CombatTab:CreateToggle({Name = "ล่าบอสอัตโนมัติ (Auto Boss)", CurrentValue = false, Callback = function(V) _G.AutoBoss = V end})
CombatTab:CreateToggle({Name = "รัศมีสังหาร (Smart Kill Aura)", CurrentValue = false, Callback = function(V) _G.KillAura = V end})

-- 🍎 ไอเทม & อีเวนท์
local ItemTab = Window:CreateTab("🍎 ไอเทม & กิจกรรม", 4483362458)
ItemTab:CreateToggle({Name = "ค้นหาและเก็บผลไม้อัตโนมัติ", CurrentValue = false, Callback = function(V) _G.AutoGrabFruit = V end})
ItemTab:CreateToggle({Name = "ฟาร์มมอนสเตอร์อีเวนท์ใหม่", CurrentValue = false, Callback = function(V) _G.AutoEvent = V end})
ItemTab:CreateButton({Name = "สุ่มผลไม้ (Auto Roll Fruit)", Callback = function() 
    pcall(function() game:GetService("ReplicatedStorage").Events.FruitRemote:FireServer("Roll") end) 
end})

-- ⚙️ ระบบเสริม & ประหยัดแบต
local SysTab = Window:CreateTab("⚙️ ระบบ", 4483362458)
SysTab:CreateSlider({Name = "ความเร็ววาร์ป (Tween Speed)", Range = {50, 300}, Increment = 10, CurrentValue = 150, Callback = function(V) _G.TweenSpeed = V end})
SysTab:CreateButton({Name = "🚀 ลบขยะกราฟิก (Extreme Boost)", Callback = OptimizeGame})
SysTab:CreateButton({Name = "🌙 เปิดโหมด AFK (จอดำ ประหยัดแบต)", Callback = function() SetAFKMode(true) end})
SysTab:CreateButton({Name = "🔄 สลับเซิร์ฟเวอร์ (หนีคน/หาบอส)", Callback = ServerHop})

-- 📜 เครดิต
local CreditTab = Window:CreateTab("📜 เครดิต", 4483362458)
CreditTab:AddLabel("ผู้พัฒนา: Prime Store")
CreditTab:AddLabel("ลิขสิทธิ์: องค์กร Prime Store")
CreditTab:AddLabel("สถานะ: ระบบ VIP ทำงานสมบูรณ์ 100%")

-- ==========================================
-- 🔄 ลูปการทำงานเบื้องหลัง (Background Loops)
-- ==========================================
task.spawn(function()
    while task.wait(0.1) do
        pcall(function()
            -- อัปเดตสถิติหน้าจอ
            if Player:FindFirstChild("Data") then
                StatsLabel:Set("เลเวล: " .. Player.Data.Level.Value .. " | เงิน: " .. Player.Data.Beli.Value)
            end
            
            -- ระบบดึงมอนสเตอร์
            BringMonsters()
            
            -- ระบบค้นหาและเก็บผลไม้
            if _G.AutoGrabFruit then
                for _, v in pairs(workspace:GetChildren()) do
                    if v:IsA("Tool") and v.Name:find("Fruit") and v:FindFirstChild("Handle") then
                        SafeTween(v.Handle.CFrame)
                    end
                end
            end
            
            -- ระบบ Kill Aura (โจมตีรอบตัว)
            if _G.KillAura then
                for _, v in pairs(workspace.Enemies:GetChildren()) do
                    if v:FindFirstChild("HumanoidRootPart") and (v.HumanoidRootPart.Position - GetRoot().Position).Magnitude <= 30 then
                        -- [ สำคัญ ] แก้ไข Event Remote ให้ตรงกับเกม Sailor Piece
                        -- game:GetService("ReplicatedStorage").Events.Attack:FireServer(v)
                    end
                end
            end
        end)
    end
end)

Rayfield:LoadConfiguration()
